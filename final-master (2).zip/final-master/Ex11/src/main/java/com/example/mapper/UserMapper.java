package com.example.mapper;

import com.example.domain.UserVO;

public interface UserMapper {

	public UserVO login(String uid);
}
