package com.example.mapper_oracle;

import java.util.HashMap;
import java.util.List;

import com.example.domain.CategoryVO;
import com.example.domain.CompanyVO;


public interface CompanyMapper {

	public CompanyVO companylist(String number);
}
