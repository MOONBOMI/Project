package com.example.mapper_oracle;

import java.util.HashMap;
import java.util.List;

import com.example.domain.DateVO;

public interface DateMapper {

	public List<HashMap<String, Object>> datelist();
}
