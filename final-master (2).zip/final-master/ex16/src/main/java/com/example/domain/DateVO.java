package com.example.domain;

import java.util.Date;

public class DateVO {

	private Date day;
	private Number wom;
}
