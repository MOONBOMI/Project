package com.example.mapper;

import com.example.domain.CgvVO;

public interface CgvMapper {

	public void insert(CgvVO vo);
}
