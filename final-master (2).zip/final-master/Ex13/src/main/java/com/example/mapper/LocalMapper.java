package com.example.mapper;

import com.example.domain.LocalVO;

public interface LocalMapper {

	public void insert(LocalVO vo);
}
