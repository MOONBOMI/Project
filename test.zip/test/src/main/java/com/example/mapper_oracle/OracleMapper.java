package com.example.mapper_oracle;

public interface OracleMapper {
	public String getTime();
}
