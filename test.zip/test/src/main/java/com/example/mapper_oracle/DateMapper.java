package com.example.mapper_oracle;

import java.util.List;

import com.example.domain.DatedataVO;


public interface DateMapper {

	public List<DatedataVO> list();
}
