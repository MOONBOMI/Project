package com.example.mapper_oracle;

import com.example.domain.LcategoryVO;

public interface LcategoryMapper {

	public void insert(LcategoryVO vo);
}
