package com.example.mapper_oracle;

import com.example.domain.McategoryVO;

public interface McategoryMapper {

	public void insert(McategoryVO vo);
}
