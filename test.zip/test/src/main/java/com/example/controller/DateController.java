package com.example.controller;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.domain.DatedataVO;
import com.example.mapper_oracle.DateMapper;

@Controller
public class DateController {

	@Autowired
	DateMapper mapper;
	
	@RequestMapping("date")
	public void date(){
		
	}
	
	@RequestMapping("datecal.json")
	@ResponseBody
	public List<DatedataVO> list(){
		List<DatedataVO> array=mapper.list();
		return array;
	}
	
	@RequestMapping("datecal")
	public void datacal(){
		
	}
}
