package com.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.example.domain.LcategoryVO;
import com.example.domain.McategoryVO;
import com.example.mapper_oracle.LcategoryMapper;
import com.example.mapper_oracle.McategoryMapper;

@Controller
public class TestController {

	@Autowired
	LcategoryMapper Lmapper;
	@Autowired
	McategoryMapper Mmapper;
	
	@RequestMapping("insert")
	public void insert(){
		
	}
	
	@RequestMapping(value="insert", method=RequestMethod.POST)
	public void insertpost(LcategoryVO vo){
		Lmapper.insert(vo);
	}
	
	@RequestMapping("minsert")
	public void minsert(){
		
	}
	
	@RequestMapping(value="minsert", method=RequestMethod.POST)
	public void minsertpost(McategoryVO vo){
		LcategoryVO lvo=new LcategoryVO();
		vo.setLcode(lvo.getLcategorycode());
		System.out.println(vo);
		Mmapper.insert(vo);
	}
	
	
}
