package com.example.domain;

public class McategoryVO {
	
	private String lcode;
	private String mcategorycode;
	private String mcategoryname;
	
	
	public String getLcode() {
		return lcode;
	}
	public void setLcode(String lcode) {
		this.lcode = lcode;
	}
	public String getMcategorycode() {
		return mcategorycode;
	}
	public void setMcategorycode(String mcategorycode) {
		this.mcategorycode = mcategorycode;
	}
	public String getMcategoryname() {
		return mcategoryname;
	}
	public void setMcategoryname(String mcategoryname) {
		this.mcategoryname = mcategoryname;
	}
	@Override
	public String toString() {
		return "McategoryVO [lcode=" + lcode + ", mcategorycode=" + mcategorycode + ", mcategoryname=" + mcategoryname
				+ "]";
	}
	
	
}
