package com.example.domain;

import java.util.Date;

public class DatedataVO {

	private Date day;
	private Number wom;
	
	public Date getDay() {
		return day;
	}
	public void setDay(Date day) {
		this.day = day;
	}
	public Number getWom() {
		return wom;
	}
	public void setWom(Number wom) {
		this.wom = wom;
	}
	
	
	@Override
	public String toString() {
		return "DatedataVO [day=" + day + ", wom=" + wom + "]";
	}
	
	
}
