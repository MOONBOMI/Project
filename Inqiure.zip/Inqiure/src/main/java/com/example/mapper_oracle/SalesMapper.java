package com.example.mapper_oracle;

import com.example.domain.SalesVO;

public interface SalesMapper {

	public void salesinsert(SalesVO vo);
}
